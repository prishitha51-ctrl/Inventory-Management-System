module.exports = {
  plugins: {
    // Reverting to the name required by Tailwind v3
    tailwindcss: {}, 
    'autoprefixer': {},
  },
}